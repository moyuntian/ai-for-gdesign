## 4. Pane Behavior

