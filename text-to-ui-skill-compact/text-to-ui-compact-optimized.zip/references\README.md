# references/ 目录导航

本目录是 text-to-ui-compact 的路由与参考资料入口。模型按以下三类决定读取范围，避免整份扫读脚本生成材料。

## A. 路由必读（三层路由 + 资料查询协议）

模型按任务进度读取这些文件：

- `routes/index.json` — 6 条 Workflow route 入口
- `routes/<id>.md` — 选定 Workflow route 的详细流程（new-page / micro-revision / existing-html-to-pixso / pixso-component-library / converter-diagnosis / skill-maintenance）
- `index/task-routes.source.json` — Task route 维护源
- `index/layout-routes.source.json` — Layout Pattern 维护源
- `index/capability-aliases.source.json` — 组件能力别名
- `routing-guide.md` — 三层路由快速调用说明
- `resource-workflow.md` — 按需资料查询协议
- `routes/materials.source.json` — route 材料映射

## B. 按需查询（用脚本切片，不整份读）

通过 `scripts/query-resources.mjs --stage` / `query-components.mjs --component` / `query-tokens.mjs --roles` 按需切片读取：

- `resources/<topic>/` — 14 个主题的维护源小文件（requirements、layout、patterns、interaction、composition、blueprint、design、supplement、titlebar、delivery、pixso-pipeline、pixso-mcp、pixso-scene、pixso-detail）
- `packages/component-contracts/src/components/<id>.json` — 49 个组件契约（按 ID 单个读）
- `packages/tokens/src/` — Token 值与 CSS 变量（--roles 精确查）
- `packages/components-html/src/` — HTML 组件运行时源码
- `packages/pattern-runtime/src/` — Pattern 运行时
- `assets/design-system/` — pattern-contracts.json、mapping-registry.json、harmonyos-layout-references、icons

## C. 脚本生成，模型默认不直接读

以下文件由脚本生成，手改无效。模型默认不直接读；需要时通过查询脚本切片获取，或仅在维护任务中按脚本流程重建：

### 索引（references/index/generated/）

由 `pnpm index:build` / `catalog:build` / `resources:build` 生成：

- `index/generated/resource-index.json`
- `index/generated/token-index.json`
- `index/generated/skill-catalog-index.json`
- `index/generated/layout-index.json`
- `index/generated/route-material-index.json`
- `index/generated/component-index.json`
- `index/generated/validation-index.json`

### 兼容聚合产物（14 份，源在 `resources/<topic>/`）

`resources/source.json` 中标记 `policy: "generated-compatibility-aggregate"`。改源后运行 `pnpm resources:build` 重建：

| 聚合产物 | 源目录 |
| --- | --- |
| `requirement-spec.md` | `resources/requirements/` |
| `layout-system.md` | `resources/layout/` |
| `harmonyos-layout-patterns.md` | `resources/patterns/` |
| `interaction-spec.md` | `resources/interaction/` |
| `components/page-composition.md` | `resources/composition/` |
| `page-blueprint-design.md` | `resources/blueprint/` |
| `page-design-guidance.md` | `resources/design/` |
| `component-specs-extended.md` | `resources/supplement/` |
| `components/titlebar-segments.md` | `resources/titlebar/` |
| `components/local-component-delivery.md` | `resources/delivery/` |
| `pixso-fidelity-import-pipeline.md` | `resources/pixso-pipeline/` |
| `pixso-mcp.md` | `resources/pixso-mcp/` |
| `pixso-native-scene.md` | `resources/pixso-scene/` |
| `pixso-import-details.md` | `resources/pixso-detail/` |

### 其他脚本生成

- `mapping-registry.md` — 由 `pnpm mappings:doc` 生成（源在 `assets/design-system/mapping-registry.json`）
- `harmonyos-component-mapping-table.md` — 由 `build-harmonyos-component-mapping-table.mjs` 生成

### 项目根级（不进 references）

- `.delivery-manifest.json` — 由 `scripts/skill-delivery.mjs` 生成，跟踪全目录 sha256

## 维护原则

- 修改 `resources/<topic>/` 小文件后，运行 `pnpm resources:build` 重建聚合产物与索引
- 刷新顺序：`resources:build → catalog:build → index:build`，对应 `--check` 通过后刷新 `.delivery-manifest.json`
- 不得手改聚合产物或 generated 索引（手改无效，下次重建被覆盖）
- 详细协议见 `resource-workflow.md` 和 `routing-guide.md`
