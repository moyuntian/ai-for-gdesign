# 页面本地组件与动态渲染

这个流程把模型负责的页面设计和脚本负责的组件交付分开。AI 根据三层路由与 page-brief.json 写页面参数；脚本将选中的组件入口与运行依赖放入页面项目。

## 读取范围

先读取 SKILL.md、当前操作路由和 page-brief.json v2 的路由导航，再用 query-resources.mjs 领取当前阶段的任务包。
组件名称/用途在 discovery 包；参数/插槽/变体/当前语义在 bindings 包，必须选择精确 ID 和语义。Token 用 --roles 精确查。
完整 context.json、聚合手册、组件总表与实现由脚本使用。需要细节时查询资源 ID 或单个 contractPath。详见 references/resource-workflow.md。

## 项目输出

~~~text
PROJECT_DIR/
  components/
    index.js                    本页可用的组件注册表
    component-manifest.json     选择结果、输入摘要、来源和输出摘要
    package.json                本地 ES module 边界
    button/
      index.js                  调用注册 HTML 工厂的独立入口
      contract.json             此组件的原始契约
    <其他已选组件>/
    _runtime/
      packages/                 共用工厂、Pattern、CSS 与 Token 依赖闭包
  generated-page.js             页面组合与动态 renderGeneratedPage
  generated-entry.js            挂载、事件、组件初始化、截图就绪信号
  page-blueprint.json
  page-content-recipes.json
  page-bindings.json
  styles/
    index.css                   脚本生成的统一样式入口
    base.css                    脚本生成的视口基础样式
    page-composition.css        模型编写的业务容器布局
    style-manifest.json         样式依赖、加载顺序与摘要
  component-usage.json
  html-page-manifest.json
  index.html
  main.js
~~~

components/<id>/index.js 是真实工厂调用适配器，组件 DOM 和内部样式仍来自 Skill 的 HTML 实现。当前组件工厂在公共 index.js 中集中登记，所以公共运行时仍包含共享注册代码。选中组件的入口与契约按需交付；上下文减少不等于运行时已按字节完全拆分。

## 两阶段命令

一键生成器会自动完成下面的组件准备。需要先交给另一个模型继续写页面时，也可以显式执行：

~~~bash
node "<RULES_ROOT>/scripts/prepare-page-components.mjs" \
  --project "<PROJECT_DIR>" --context "<PROJECT_DIR>/.text-to-ui/context-packet.json" \
  --bindings "<PROJECT_DIR>/page-bindings.json" --skill-root "<RULES_ROOT>"
~~~

省略 --bindings 时，准备 Context Packet 当前选定的组件；提供 --bindings 时，仅准备实际绑定的组件。后续新增组件先重新解析能力，再重跑准备脚本。重复运行只更新自己的清单文件；遇到已被手改的管理文件会停止。

用同一参数加 --check 可检查依赖是否丢失或发生改动。生成器在组件准备和最终生成时核对材料与来源；来源变化后重新解析路由，修正输入再生成。

## 样式装配与读取边界

一键生成器在组件准备后自动执行 scripts/prepare-page-styles.mjs。main.js 只导入 styles/index.css，然后调用挂载模块；generated-page.js 和 generated-entry.js 不导入 CSS。index.html 不包含内联样式或额外样式链接。

加载顺序固定为：canonical Tokens → styles/base.css → 标准 HTML 组件样式 → Pattern shell → Pattern Runtime → styles/page-composition.css。标准组件样式内部已有自己的依赖引用，保持其原始关系，由构建工具处理。不要为了目录对称把共享 CSS 拆成 49 份。

模型只需读取相关 Token 和组件参数，编写 styles/page-composition.css 中业务容器的布局。不在其中写 @import、复制组件内部规则或覆盖 Pattern 几何。新增组件后重新走组件准备与样式装配；不要手工改管理文件。

在组件与宿主已准备好后，可单独装配或检查：

~~~bash
node "<RULES_ROOT>/scripts/prepare-page-styles.mjs" --project "<PROJECT_DIR>"
node "<RULES_ROOT>/scripts/prepare-page-styles.mjs" --project "<PROJECT_DIR>" --check
~~~

默认页面 CSS 为 styles/page-composition.css。已有项目可以显式传 --page-css "<PROJECT_DIR>/page-composition.css"，保留原文件位置。旧脚本生成的 main.js 与精确的基础内联 reset 可自动迁移；自定义主入口、额外内联样式、手改的管理样式会停止并提示冲突，不覆盖业务代码。组件/样式清单的来源与输出摘要必须匹配；失败时恢复本次准备前的管理文件。

## 页面调用

生成的页面导入本项目组件注册表：

~~~javascript
import { renderHtmlComponent } from "./components/index.js";
const saveButton = renderHtmlComponent("button", {
  label: "保存", variant: "primary", size: "standard", mode: "text"
});
~~~

此例仅展示调用形状。正式页面由严格生成器根据 Blueprint、配方、绑定和行为计划生成。组件内容必须通过支持的参数与插槽传入，几何由所选 Pattern Runtime 管理，页面 CSS 使用 Token。

## Pixso 衔接

先在 HTTP 预览中等待 document.querySelector("#app").__tuiReady，确认 data-tui-ready 为 ready，再固定状态和视口、截取同一页面。root.__tuiReady 返回组件证据；截图就绪仅证明资源加载完成，仍需检查交互与视觉。

接着走 existing-html-to-pixso 操作路由。输入是实际渲染的 HTML，保留 component-manifest.json、styles/style-manifest.json、component-usage.json 和生成收据供追溯。现有导入运行的捕获包、几何编译、变量/组件匹配、发布、回读和像素对比继续适用。不要在 Skill 维护期间直接向 Pixso 发布页面。
