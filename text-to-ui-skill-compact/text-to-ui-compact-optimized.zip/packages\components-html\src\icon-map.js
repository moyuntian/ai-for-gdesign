// Generated from packages/components-html/src/component-icons.svg. Do not edit by hand.
export const iconDefinitions = {
  "action/add": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M5 12h14\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 5v14\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "plus"
  },
  "action/archive": {
    "viewBox": "0 0 24 24",
    "content": "<rect width=\"20\" height=\"5\" x=\"2\" y=\"3\" rx=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M10 12h4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "archive"
  },
  "action/check": {
    "viewBox": "0 0 24 24",
    "content": "<circle cx=\"12\" cy=\"12\" r=\"10\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m9 12 2 2 4-4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "circle-check"
  },
  "action/close": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M18 6 6 18\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m6 6 12 12\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "x"
  },
  "action/copy": {
    "viewBox": "0 0 24 24",
    "content": "<rect width=\"14\" height=\"14\" x=\"8\" y=\"8\" rx=\"2\" ry=\"2\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "copy"
  },
  "action/delete": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M10 11v6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M14 11v6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M3 6h18\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "trash-2"
  },
  "action/download": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M12 15V3\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m7 10 5 5 5-5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "download"
  },
  "action/filter": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M2 5h20\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M6 12h12\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M9 19h6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "list-filter"
  },
  "action/forward": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"m15 17 5-5-5-5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M4 18v-2a4 4 0 0 1 4-4h12\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "forward"
  },
  "action/mark-important": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "flag"
  },
  "action/mark-unread": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M21.2 8.4c.5.38.8.97.8 1.6v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V10a2 2 0 0 1 .8-1.6l8-6a2 2 0 0 1 2.4 0l8 6Z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m22 10-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 10\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "mail-open"
  },
  "action/more": {
    "viewBox": "0 0 24 24",
    "content": "<circle cx=\"12\" cy=\"12\" r=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"19\" cy=\"12\" r=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"5\" cy=\"12\" r=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "ellipsis"
  },
  "action/multi-select": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M16 5H3\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 12H3\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M11 19H3\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m15 18 2 2 4-4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "list-check"
  },
  "action/refresh": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M21 3v5h-5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 16H3v5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "refresh-cw"
  },
  "action/reply": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M20 18v-2a4 4 0 0 0-4-4H4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m9 17-5-5 5-5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "reply"
  },
  "action/reply-all": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"m12 17-5-5 5-5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M22 18v-2a4 4 0 0 0-4-4H7\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m7 17-5-5 5-5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "reply-all"
  },
  "action/rename": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M13 21h8\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m15 5 4 4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "pencil-line"
  },
  "action/save": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M7 3v4a1 1 0 0 0 1 1h7\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "save"
  },
  "action/settings": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"12\" cy=\"12\" r=\"3\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "settings"
  },
  "action/sort-ascending": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M3 19h18\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M15 12H3\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M9 5H3\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "list-sort-ascending"
  },
  "field/search": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"m21 21-4.34-4.34\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"11\" cy=\"11\" r=\"8\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "search"
  },
  "field/date": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M8 2v4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 2v4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect width=\"18\" height=\"18\" x=\"3\" y=\"4\" rx=\"2\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M3 10h18\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 14h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 14h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 14h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 18h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 18h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 18h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "calendar-days"
  },
  "field/calendar": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M8 2v4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 2v4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect width=\"18\" height=\"18\" x=\"3\" y=\"4\" rx=\"2\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M3 10h18\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 14h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 14h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 14h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 18h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 18h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 18h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "calendar-days"
  },
  "field/time": {
    "viewBox": "0 0 24 24",
    "content": "<circle cx=\"12\" cy=\"12\" r=\"10\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 6v6h4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "clock-3"
  },
  "field/clock": {
    "viewBox": "0 0 24 24",
    "content": "<circle cx=\"12\" cy=\"12\" r=\"10\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 6v6h4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "clock-3"
  },
  "navigation/archive": {
    "viewBox": "0 0 24 24",
    "content": "<rect width=\"20\" height=\"5\" x=\"2\" y=\"3\" rx=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M10 12h4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "archive"
  },
  "navigation/back": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"m12 19-7-7 7-7\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M19 12H5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "arrow-left"
  },
  "navigation/chevron-down": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"m6 9 6 6 6-6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "chevron-down"
  },
  "navigation/chevron-right": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"m9 18 6-6-6-6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "chevron-right"
  },
  "navigation/chevron-up": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"m18 15-6-6-6 6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "chevron-up"
  },
  "navigation/deleted": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M10 11v6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M14 11v6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M3 6h18\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "trash-2"
  },
  "navigation/drafts": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M14.487 7.858A1 1 0 0 1 14 7V2\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 18h1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "file-pen-line"
  },
  "navigation/forward": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M5 12h14\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m12 5 7 7-7 7\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "arrow-right"
  },
  "navigation/grid": {
    "viewBox": "0 0 24 24",
    "content": "<rect width=\"7\" height=\"7\" x=\"3\" y=\"3\" rx=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect width=\"7\" height=\"7\" x=\"14\" y=\"3\" rx=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect width=\"7\" height=\"7\" x=\"14\" y=\"14\" rx=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect width=\"7\" height=\"7\" x=\"3\" y=\"14\" rx=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "layout-grid"
  },
  "navigation/inbox": {
    "viewBox": "0 0 24 24",
    "content": "<polyline points=\"22 12 16 12 14 15 10 15 8 12 2 12\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "inbox"
  },
  "navigation/contacts": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M18 21a8 8 0 0 0-16 0\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"10\" cy=\"8\" r=\"5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "users-round"
  },
  "navigation/mail-unread": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M21.2 8.4c.5.38.8.97.8 1.6v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V10a2 2 0 0 1 .8-1.6l8-6a2 2 0 0 1 2.4 0l8 6Z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m22 10-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 10\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "mail-open"
  },
  "navigation/outbox": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M3.714 3.048a.498.498 0 0 0-.683.627l2.843 7.627a2 2 0 0 1 0 1.396l-2.842 7.627a.498.498 0 0 0 .682.627l18-8.5a.5.5 0 0 0 0-.904z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M6 12h16\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "send-horizontal"
  },
  "navigation/list": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M3 5h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M3 12h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M3 19h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 5h13\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 12h13\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 19h13\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "list"
  },
  "navigation/panel-left": {
    "viewBox": "0 0 24 24",
    "content": "<rect width=\"18\" height=\"18\" x=\"3\" y=\"3\" rx=\"2\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M9 3v18\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "panel-left"
  },
  "navigation/recent": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M3 3v5h5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 7v5l4 2\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "history"
  },
  "navigation/sent": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m21.854 2.147-10.94 10.939\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "send"
  },
  "navigation/spam": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M12 16h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 8v4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M15.312 2a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586l-4.688-4.688A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "octagon-alert"
  },
  "navigation/starred": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "star"
  },
  "object/attachment": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"m16 6-8.414 8.586a2 2 0 0 0 2.829 2.829l8.414-8.586a4 4 0 1 0-5.657-5.657l-8.379 8.551a6 6 0 1 0 8.485 8.485l8.379-8.551\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "paperclip"
  },
  "object/file": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M14 2v5a1 1 0 0 0 1 1h5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "file"
  },
  "object/avatar": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"12\" cy=\"7\" r=\"4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "user"
  },
  "object/device": {
    "viewBox": "0 0 24 24",
    "content": "<rect width=\"14\" height=\"20\" x=\"5\" y=\"2\" rx=\"2\" ry=\"2\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 18h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "smartphone"
  },
  "status/error": {
    "viewBox": "0 0 24 24",
    "content": "<circle cx=\"12\" cy=\"12\" r=\"10\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m15 9-6 6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m9 9 6 6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "circle-x"
  },
  "status/danger": {
    "viewBox": "0 0 24 24",
    "content": "<circle cx=\"12\" cy=\"12\" r=\"10\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m15 9-6 6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m9 9 6 6\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "circle-x"
  },
  "status/info": {
    "viewBox": "0 0 24 24",
    "content": "<circle cx=\"12\" cy=\"12\" r=\"10\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 16v-4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 8h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "info"
  },
  "status/loading": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M21 12a9 9 0 1 1-6.219-8.56\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "loader-circle"
  },
  "status/neutral": {
    "viewBox": "0 0 24 24",
    "content": "<circle cx=\"12\" cy=\"12\" r=\"10\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 12h8\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "circle-minus"
  },
  "status/success": {
    "viewBox": "0 0 24 24",
    "content": "<circle cx=\"12\" cy=\"12\" r=\"10\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m9 12 2 2 4-4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "circle-check"
  },
  "status/warning": {
    "viewBox": "0 0 24 24",
    "content": "<circle cx=\"12\" cy=\"12\" r=\"10\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"12\" x2=\"12\" y1=\"8\" y2=\"12\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><line x1=\"12\" x2=\"12.01\" y1=\"16\" y2=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "circle-alert"
  },
  "primary-level/overview": {
    "viewBox": "0 0 24 24",
    "content": "<rect width=\"7\" height=\"7\" x=\"3\" y=\"3\" rx=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect width=\"7\" height=\"7\" x=\"14\" y=\"3\" rx=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect width=\"7\" height=\"7\" x=\"14\" y=\"14\" rx=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect width=\"7\" height=\"7\" x=\"3\" y=\"14\" rx=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "layout-grid"
  },
  "primary-level/calendar": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M8 2v4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 2v4\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><rect width=\"18\" height=\"18\" x=\"3\" y=\"4\" rx=\"2\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M3 10h18\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 14h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 14h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 14h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M8 18h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 18h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M16 18h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "calendar-days"
  },
  "primary-level/contacts": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M18 21a8 8 0 0 0-16 0\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"10\" cy=\"8\" r=\"5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "users-round"
  },
  "primary-level/mail": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M21.2 8.4c.5.38.8.97.8 1.6v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V10a2 2 0 0 1 .8-1.6l8-6a2 2 0 0 1 2.4 0l8 6Z\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"m22 10-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 10\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "mail-open"
  },
  "primary-level/settings": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><circle cx=\"12\" cy=\"12\" r=\"3\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>",
    "source": "lucide@1.24.0",
    "name": "settings"
  },
  "choice/check": {
    "viewBox": "0 0 13.9646 13.5884",
    "content": "<path d=\"M6.9995 10.2176C6.99984 10.2282 7 10.2388 7 10.2495C7 10.5225 6.89058 10.77 6.7132 10.9505C6.53174 11.1353 6.27902 11.25 5.9995 11.25C5.9888 11.25 5.97812 11.2498 5.9675 11.2495L1 11.2495C0.44772 11.2495 0 10.8018 0 10.2495C0 9.69722 0.44772 9.2495 1 9.2495L4.9995 9.2495L4.9995 1C4.9995 0.44772 5.44722 0 5.9995 0C6.5518 0 6.9995 0.44772 6.9995 1L6.9995 10.2176Z\" fill=\"rgb(255,255,255)\" fill-rule=\"evenodd\" transform=\"matrix(0.731354,0.681998,-0.681998,0.731354,8.25879,0)\" />\n  <path d=\"M8 10.2495C8 10.2344 7.99983 10.2193 7.9995 10.2044L7.9995 1C7.9995 -0.10458 7.10408 -1 5.9995 -1C4.89494 -1 3.9995 -0.10456 3.9995 1L3.9995 8.2495L1 8.2495C-0.104559 8.2495 -1 9.14494 -1 10.2495C-1 11.3541 -0.10456 12.2495 1 12.2495L5.95432 12.2495C5.96925 12.2498 5.98431 12.25 5.9995 12.25Q6.42018 12.25 6.77761 12.0996Q7.13331 11.95 7.42637 11.6515Q7.71313 11.3597 7.85654 11.0093Q8 10.6588 8 10.2495ZM7 10.2495C7 10.2388 6.99984 10.2282 6.9995 10.2176L6.9995 1C6.9995 0.44772 6.5518 0 5.9995 0C5.44722 0 4.9995 0.44772 4.9995 1L4.9995 9.2495L1 9.2495C0.44772 9.2495 0 9.69722 0 10.2495C0 10.8018 0.44772 11.2495 1 11.2495L5.9675 11.2495C5.97812 11.2498 5.9888 11.25 5.9995 11.25C6.27902 11.25 6.53174 11.1353 6.7132 10.9505C6.89058 10.77 7 10.5225 7 10.2495Z\" fill=\"rgb(0,0,0)\" fill-opacity=\"0.0470588244\" fill-rule=\"evenodd\" transform=\"matrix(0.731354,0.681998,-0.681998,0.731354,8.25879,0)\" />",
    "source": "asset",
    "path": "assets/icons/harmonyos/regular/checkbox-check.svg",
    "preservePaint": true
  },
  "window/close": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M.75 0H15.5992C16.0192 0 16.3492.33 16.3492.75C16.3492 1.17 16.0192 1.5 15.5992 1.5H.75C.33 1.5 0 1.17 0 .75C0 .33.33 0 .75 0Z\" fill=\"currentColor\" fill-rule=\"evenodd\" transform=\"matrix(.707107 .707107 -.707107 .707107 6.75 5.68896)\"/>\n  <path d=\"M.75 0H15.5992C16.0192 0 16.3492.33 16.3492.75C16.3492 1.17 16.0192 1.5 15.5992 1.5H.75C.33 1.5 0 1.17 0 .75C0 .33.33 0 .75 0Z\" fill=\"currentColor\" fill-rule=\"evenodd\" transform=\"matrix(-.707107 .707107 .707107 .707107 17.25 5.68896)\"/>",
    "source": "asset",
    "path": "assets/icons/titlebar/window-close.svg"
  },
  "window/maximize": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M5.25 7.33333V10.8C5.25 11.22 5.58 11.55 6 11.55C6.42 11.55 6.75 11.22 6.75 10.8V7.33333C6.75 7.25279 6.76424 7.17815 6.79271 7.1094C6.82119 7.04065 6.8639 6.97781 6.92085 6.92085C6.97781 6.8639 7.04065 6.82119 7.1094 6.79271C7.17815 6.76424 7.25279 6.75 7.33333 6.75H10.8C11.22 6.75 11.55 6.42 11.55 6C11.55 5.58 11.22 5.25 10.8 5.25H7.33333C7.18252 5.25 7.0351 5.26561 6.89106 5.29683C6.76553 5.32404 6.64257 5.36311 6.52218 5.41403C6.40243 5.46467 6.2893 5.5253 6.18279 5.5959C6.06751 5.67231 5.95998 5.76041 5.86019 5.86019C5.76041 5.95998 5.67231 6.06751 5.5959 6.18279C5.5253 6.2893 5.46467 6.40243 5.41403 6.52218C5.36311 6.64257 5.32404 6.76553 5.29683 6.89106C5.26561 7.0351 5.25 7.18252 5.25 7.33333ZM18.75 13.2C18.75 12.78 18.42 12.45 18 12.45C17.58 12.45 17.25 12.78 17.25 13.2V16.6667C17.25 16.7472 17.2358 16.8219 17.2073 16.8906C17.1788 16.9593 17.1361 17.0222 17.0791 17.0791C17.0222 17.1361 16.9593 17.1788 16.8906 17.2073C16.8219 17.2358 16.7472 17.25 16.6667 17.25H13.2C12.78 17.25 12.45 17.58 12.45 18C12.45 18.42 12.78 18.75 13.2 18.75H16.6667C16.8175 18.75 16.9649 18.7344 17.1089 18.7032C17.2344 18.676 17.3574 18.6369 17.4778 18.586C17.7272 18.4805 17.9478 18.3318 18.1398 18.1398C18.3318 17.9478 18.4805 17.7272 18.586 17.4778C18.6953 17.2193 18.75 16.9489 18.75 16.6667V13.2Z\" fill=\"currentColor\" fill-rule=\"evenodd\"/>",
    "source": "asset",
    "path": "assets/icons/titlebar/window-maximize.svg"
  },
  "window/minimize": {
    "viewBox": "0 0 24 24",
    "content": "<path d=\"M5.25 11.25H18.75C19.17 11.25 19.5 11.58 19.5 12C19.5 12.42 19.17 12.75 18.75 12.75H5.25C4.83 12.75 4.5 12.42 4.5 12C4.5 11.58 4.83 11.25 5.25 11.25Z\" fill=\"currentColor\" fill-rule=\"evenodd\"/>",
    "source": "asset",
    "path": "assets/icons/titlebar/window-minimize.svg"
  }
};
const flatAliasAliases = Object.freeze({"action-add":"action/add","action-archive":"action/archive","action-check":"action/check","action-close":"action/close","action-copy":"action/copy","action-delete":"action/delete","action-download":"action/download","action-filter":"action/filter","action-forward":"action/forward","action-mark-important":"action/mark-important","action-mark-unread":"action/mark-unread","action-more":"action/more","action-multi-select":"action/multi-select","action-refresh":"action/refresh","action-reply":"action/reply","action-reply-all":"action/reply-all","action-rename":"action/rename","action-save":"action/save","action-settings":"action/settings","action-sort-ascending":"action/sort-ascending","field-search":"field/search","field-date":"field/date","field-calendar":"field/calendar","field-time":"field/time","field-clock":"field/clock","navigation-archive":"navigation/archive","navigation-back":"navigation/back","navigation-chevron-down":"navigation/chevron-down","navigation-chevron-right":"navigation/chevron-right","navigation-chevron-up":"navigation/chevron-up","navigation-deleted":"navigation/deleted","navigation-drafts":"navigation/drafts","navigation-forward":"navigation/forward","navigation-grid":"navigation/grid","navigation-inbox":"navigation/inbox","navigation-contacts":"navigation/contacts","navigation-mail-unread":"navigation/mail-unread","navigation-outbox":"navigation/outbox","navigation-list":"navigation/list","navigation-panel-left":"navigation/panel-left","navigation-recent":"navigation/recent","navigation-sent":"navigation/sent","navigation-spam":"navigation/spam","navigation-starred":"navigation/starred","object-attachment":"object/attachment","object-file":"object/file","object-avatar":"object/avatar","object-device":"object/device","status-error":"status/error","status-danger":"status/danger","status-info":"status/info","status-loading":"status/loading","status-neutral":"status/neutral","status-success":"status/success","status-warning":"status/warning","primary-level-overview":"primary-level/overview","primary-level-calendar":"primary-level/calendar","primary-level-contacts":"primary-level/contacts","primary-level-mail":"primary-level/mail","primary-level-settings":"primary-level/settings","choice-check":"choice/check","window-close":"window/close","window-maximize":"window/maximize","window-minimize":"window/minimize"});
const compatibilityAliases = Object.freeze({"disclosure-down":"navigation/chevron-down","disclosure-right":"navigation/chevron-right","disclosure-up":"navigation/chevron-up","window-minimize":"window/minimize","window-maximize":"window/maximize","window-close":"window/close","close":"action/close","trash":"action/delete","document":"object/file","download":"action/download","refresh":"action/refresh","add":"action/add","settings":"action/settings","search":"field/search","more":"action/more","grid":"navigation/grid","history":"navigation/recent","user":"object/avatar","panel-left":"navigation/panel-left","device":"object/device","calendar":"field/calendar","clock":"field/clock","info":"status/info","success":"status/success","warning":"status/warning","danger":"status/danger","neutral":"status/neutral","sync":"action/refresh"});
const sourceNameAliases = Object.freeze({"plus":"action/add","archive":"navigation/archive","circle-check":"status/success","x":"action/close","copy":"action/copy","trash-2":"navigation/deleted","download":"action/download","list-filter":"action/filter","forward":"action/forward","flag":"action/mark-important","mail-open":"primary-level/mail","ellipsis":"action/more","list-check":"action/multi-select","refresh-cw":"action/refresh","reply":"action/reply","reply-all":"action/reply-all","pencil-line":"action/rename","save":"action/save","settings":"primary-level/settings","list-sort-ascending":"action/sort-ascending","search":"field/search","calendar-days":"primary-level/calendar","clock-3":"field/clock","arrow-left":"navigation/back","chevron-down":"navigation/chevron-down","chevron-right":"navigation/chevron-right","chevron-up":"navigation/chevron-up","file-pen-line":"navigation/drafts","arrow-right":"navigation/forward","layout-grid":"primary-level/overview","inbox":"navigation/inbox","users-round":"primary-level/contacts","send-horizontal":"navigation/outbox","list":"navigation/list","panel-left":"navigation/panel-left","history":"navigation/recent","send":"navigation/sent","octagon-alert":"navigation/spam","star":"navigation/starred","paperclip":"object/attachment","file":"object/file","user":"object/avatar","smartphone":"object/device","circle-x":"status/danger","info":"status/info","loader-circle":"status/loading","circle-minus":"status/neutral","circle-alert":"status/warning"});
const semanticSuffixAliases = Object.freeze({"add":"action/add","copy":"action/copy","delete":"action/delete","download":"action/download","filter":"action/filter","mark-important":"action/mark-important","mark-unread":"action/mark-unread","more":"action/more","multi-select":"action/multi-select","refresh":"action/refresh","reply":"action/reply","reply-all":"action/reply-all","rename":"action/rename","save":"action/save","sort-ascending":"action/sort-ascending","search":"field/search","date":"field/date","time":"field/time","clock":"field/clock","back":"navigation/back","chevron-down":"navigation/chevron-down","chevron-right":"navigation/chevron-right","chevron-up":"navigation/chevron-up","deleted":"navigation/deleted","drafts":"navigation/drafts","grid":"navigation/grid","inbox":"navigation/inbox","mail-unread":"navigation/mail-unread","outbox":"navigation/outbox","list":"navigation/list","panel-left":"navigation/panel-left","recent":"navigation/recent","sent":"navigation/sent","spam":"navigation/spam","starred":"navigation/starred","attachment":"object/attachment","file":"object/file","avatar":"object/avatar","device":"object/device","error":"status/error","danger":"status/danger","info":"status/info","loading":"status/loading","neutral":"status/neutral","success":"status/success","warning":"status/warning","overview":"primary-level/overview","mail":"primary-level/mail","maximize":"window/maximize","minimize":"window/minimize"});
const unresolvedIconDefinition = Object.freeze({ viewBox: "0 0 24 24", content: "<circle cx=\"12\" cy=\"12\" r=\"9\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 8v5\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M12 16h.01\" fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>", source: "unresolved-fallback", name: "unresolved", manualFallback: true });
export const iconSizes = Object.freeze({16: 16, 20: 20, 24: 24});
export const iconStrokeWidths = Object.freeze({16: 1, 20: 1.25, 24: 1.5});
const escapeAttribute = (value) => String(value).replaceAll("&", "&amp;").replaceAll('"', "&quot;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
const normalizeLookup = (value) => String(value ?? "").trim().replace(/^lucide(?::|\/)/i, "").replace(/([a-z])([A-Z])/g, "$1-$2").replace(/[\s_]+/g, "-").toLowerCase();
export function resolveIcon(name) {
  const requestedAlias = String(name ?? "").trim();
  const exact = iconDefinitions[requestedAlias];
  if (exact) return { ...exact, resolvedAlias: requestedAlias, resolution: "canonical", requestedAlias };
  const normalized = normalizeLookup(requestedAlias);
  const flatAlias = flatAliasAliases[normalized];
  if (flatAlias && iconDefinitions[flatAlias]) return { ...iconDefinitions[flatAlias], resolvedAlias: flatAlias, resolution: "flat-alias", requestedAlias };
  const compatibilityAlias = compatibilityAliases[normalized];
  if (compatibilityAlias && iconDefinitions[compatibilityAlias]) return { ...iconDefinitions[compatibilityAlias], resolvedAlias: compatibilityAlias, resolution: "compatibility-alias", requestedAlias };
  const sourceAlias = sourceNameAliases[normalized];
  if (sourceAlias && iconDefinitions[sourceAlias]) return { ...iconDefinitions[sourceAlias], resolvedAlias: sourceAlias, resolution: "source-name", requestedAlias };
  const suffixAlias = semanticSuffixAliases[normalized.split("/").at(-1)];
  if (suffixAlias && iconDefinitions[suffixAlias]) return { ...iconDefinitions[suffixAlias], resolvedAlias: suffixAlias, resolution: "semantic-suffix", requestedAlias };
  return { ...unresolvedIconDefinition, resolvedAlias: null, resolution: "unresolved-fallback", requestedAlias };
}
export function iconMarkup(name, { size = 20, decorative = true, ariaLabel = "", iconStyle = "regular" } = {}) {
  if (!["regular", "solid"].includes(iconStyle)) throw new Error(`Unsupported icon style: ${iconStyle}`);
  if (![16, 20, 24].includes(Number(size))) throw new Error(`Unsupported icon display size: ${size}`);
  const definition = resolveIcon(name);
  const label = decorative ? " aria-hidden=\"true\"" : ` role=\"img\" aria-label=\"${String(ariaLabel).replaceAll("\"", "&quot;")}\"`;
  return `<svg class=\"tui-icon tui-icon--${iconStyle}\" viewBox=\"${definition.viewBox}\" width=\"${size}\" height=\"${size}\" data-icon-alias=\"${name}\" data-icon-size=\"${size}\" data-display-size-token=\"size/${size}\" data-icon-kind=\"${iconStyle}\" data-icon-source=\"${definition.source}\"${label}>${definition.content}</svg>`;
}
