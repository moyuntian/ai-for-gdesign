## Style and behavior plans

